import { concatBytes, readU16, readU32 } from "../nds/binary";
import { readNitroResources } from "./map3dModel";
import { extendGrassDraws, packGrassCommands, terrainModelLayout, writeTerrainModel, type GpuCommand, type ModelBox, type TerrainModelLayout } from "./mapGrassGeometry";
import { mapTreeTypeForMaterials, type MapTreeType } from "./mapTreeCatalog";
import { ensure, materialRecords, replaceMaterialRecords, type NativeMaterialRecord } from "./nitroResourceWriter";

/**
 * Trees planted by the tree brush live in their own terrain shapes, one per native tree material ("t1_ki02ax" for the
 * primary collision layer, "t2_" for the second). Each tree's run of faces starts with a tag: a texture coordinate
 * that the next command always overrides, carrying the footprint's top-left tile and size, so trees can be found and
 * removed later without the source ROM. The original terrain lists stay byte-for-byte.
 */
export const TREE_SHAPE_PREFIXES = { 1: "t1_", 2: "t2_" } as const;
export type TreeMember = keyof typeof TREE_SHAPE_PREFIXES;
const TREE_TAG = 0x7ee0;
const TILE = 16;

export function treeTileKey(index: number, member: TreeMember) {
  return index + (member - 1) * 1024;
}

export function isTreeBrushShape(name: string) {
  return /^t[12]_/.test(name);
}

/** One vertex with the attributes the GPU had latched when it was submitted. Positions are relative to the footprint's top-left corner and its ground height. */
export type TreeVertex = { position: readonly [number, number, number]; color?: number; normal?: number; texcoord?: number; normalLast?: boolean };
export type TreeTemplatePart = { record: NativeMaterialRecord; shapeHeader: Uint8Array; faces: TreeVertex[][] };
export type MapTreeTemplate = { type: MapTreeType; parts: TreeTemplatePart[] };
export type TreePlacement = { tileIndex: number; ground: number; template: MapTreeTemplate };

const GPU_PARAMS: Record<number, number> = { 0: 0, 0x20: 1, 0x21: 1, 0x22: 1, 0x23: 2, 0x24: 1, 0x25: 1, 0x26: 1, 0x27: 1, 0x28: 1, 0x40: 1, 0x41: 0 };

function readCommands(list: Uint8Array, error: string): GpuCommand[] {
  const commands: GpuCommand[] = [];
  let offset = 0;
  while (offset < list.length) {
    ensure(offset + 4 <= list.length, error);
    const packet = readU32(list, offset);
    offset += 4;
    for (let byte = 0; byte < 4; byte++) {
      const op = (packet >>> (byte * 8)) & 255, count = GPU_PARAMS[op];
      ensure(count !== undefined && offset + count * 4 <= list.length, error);
      if (op) commands.push({ op, params: Array.from({ length: count }, (_, i) => readU32(list, offset + i * 4)) });
      offset += count * 4;
    }
  }
  return commands;
}

const s16 = (value: number) => (value << 16) >> 16;
const s10 = (value: number) => (value << 22) >> 22;

function position(op: number, params: number[], last: readonly number[]): [number, number, number] {
  const [a, b] = params;
  if (op === 0x23) return [s16(a) / 4096, s16(a >>> 16) / 4096, s16(b) / 4096];
  if (op === 0x24) return [s10(a) / 64, s10(a >>> 10) / 64, s10(a >>> 20) / 64];
  if (op === 0x25) return [s16(a) / 4096, s16(a >>> 16) / 4096, last[2]];
  if (op === 0x26) return [s16(a) / 4096, last[1], s16(a >>> 16) / 4096];
  if (op === 0x27) return [last[0], s16(a) / 4096, s16(a >>> 16) / 4096];
  return [last[0] + s10(a) / 4096, last[1] + s10(a >>> 10) / 4096, last[2] + s10(a >>> 20) / 4096];
}

/** Decode a native display list into faces (3 or 4 vertices each) in model units times `scale`. */
export function decodeFaces(list: Uint8Array, scale: number): TreeVertex[][] {
  const error = "A native tree uses a display list the tree brush cannot read.";
  const faces: TreeVertex[][] = [];
  let state: Omit<TreeVertex, "position"> = {};
  let last = [0, 0, 0], prim = -1, run: TreeVertex[] = [];
  const flush = () => {
    if (prim === 0) for (let i = 0; i + 2 < run.length; i += 3) faces.push(run.slice(i, i + 3));
    else if (prim === 1) for (let i = 0; i + 3 < run.length; i += 4) faces.push(run.slice(i, i + 4));
    else if (prim === 2) for (let i = 0, odd = false; i + 2 < run.length; i++, odd = !odd) faces.push(odd ? [run[i], run[i + 2], run[i + 1]] : [run[i], run[i + 1], run[i + 2]]);
    else if (prim === 3) for (let i = 0; i + 3 < run.length; i += 2) faces.push([run[i], run[i + 1], run[i + 3], run[i + 2]]);
    run = [];
  };
  for (const { op, params } of readCommands(list, error)) {
    if (op === 0x40) { flush(); prim = params[0] & 3; }
    else if (op === 0x41) { flush(); prim = -1; }
    else if (op === 0x20) state = { ...state, color: params[0], normalLast: false };
    else if (op === 0x21) state = { ...state, normal: params[0], normalLast: true };
    else if (op === 0x22) state = { ...state, texcoord: params[0] };
    else {
      ensure(prim >= 0, error);
      last = position(op, params, last);
      run.push({ ...state, position: [last[0] * scale, last[1] * scale, last[2] * scale] });
    }
  }
  flush();
  return faces;
}

/** Which material each terrain shape is drawn with, in draw order. */
function shapeMaterials(file: Uint8Array) {
  const native = readNitroResources(file).models[0];
  ensure(native, "Missing terrain model.");
  const draws: { shape: number; material: number }[] = [];
  let bound = -1;
  for (const op of native.renderOps) {
    if (op.kind === "bindMaterial") bound = op.material;
    if (op.kind === "draw") draws.push({ shape: op.piece, material: bound });
  }
  return { native, draws };
}

function rootIsIdentity(file: Uint8Array) {
  const root = readNitroResources(file).models[0]?.objects[0]?.matrix;
  return Boolean(root?.every((value, index) => value === (index % 5 === 0 ? 1 : 0)));
}

/** Cut one tree out of a vanilla map: every face of the tree's materials inside its footprint. */
export function cutMapTree(donorModel: Uint8Array, type: MapTreeType, ground: number): MapTreeTemplate {
  const changed = `The source ROM's ${type.label.toLowerCase()} (map ${type.donor.map}) is not the vanilla tree.`;
  ensure(rootIsIdentity(donorModel), changed);
  const layout = terrainModelLayout(donorModel, "tree brush");
  const records = materialRecords(donorModel);
  const { draws } = shapeMaterials(donorModel);
  const x0 = (type.donor.tileX - 16) * TILE, z0 = (type.donor.tileY - 16) * TILE, span = type.size * TILE, slack = 1.5;
  const inside = ([x, , z]: readonly number[]) => x >= x0 - slack && x <= x0 + span + slack && z >= z0 - slack && z <= z0 + span + slack;
  const parts: TreeTemplatePart[] = [];
  for (const { shape, material } of draws) {
    const record = records[material];
    if (!record || !type.materials.includes(record.name)) continue;
    const source = layout.shapes[shape];
    ensure(source, changed);
    const faces = decodeFaces(source.list, layout.scale).filter(face => face.every(vertex => inside(vertex.position)))
      .map(face => face.map(vertex => ({ ...vertex, position: [vertex.position[0] - x0, vertex.position[1] - ground, vertex.position[2] - z0] as const })));
    if (!faces.length) continue;
    const existing = parts.find(part => part.record.name === record.name);
    if (existing) existing.faces.push(...faces);
    else parts.push({ record, shapeHeader: source.header.slice(), faces });
  }
  const count = parts.reduce((total, part) => total + part.faces.reduce((sum, face) => sum + face.length - 2, 0), 0);
  ensure(count === type.donor.faces && type.materials.every(name => parts.some(part => part.record.name === name)), changed);
  return { type, parts };
}

function treeBox(placement: TreePlacement): ModelBox {
  const { tileIndex, ground, template } = placement;
  const x0 = (tileIndex % 32 - 16) * TILE, z0 = (Math.floor(tileIndex / 32) - 16) * TILE;
  const min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const part of template.parts) for (const face of part.faces) for (const { position } of face) {
    const point = [x0 + position[0], ground + position[1], z0 + position[2]];
    for (let axis = 0; axis < 3; axis++) {
      min[axis] = Math.min(min[axis], point[axis]);
      max[axis] = Math.max(max[axis], point[axis]);
    }
  }
  return { min, max };
}

function treeCommands(placement: TreePlacement, part: TreeTemplatePart, scale: number): GpuCommand[] {
  const { tileIndex, ground, template } = placement;
  const x0 = (tileIndex % 32 - 16) * TILE, z0 = (Math.floor(tileIndex / 32) - 16) * TILE;
  const coord = (value: number) => {
    const fixed = Math.round(value * 4096 / scale);
    ensure(fixed >= -32768 && fixed <= 32767, "The tree extends beyond this terrain model's coordinate range.");
    return fixed & 65535;
  };
  const commands: GpuCommand[] = [{ op: 0x22, params: [((TREE_TAG << 16) | ((template.type.size - 2) << 10) | tileIndex) >>> 0] }];
  for (const corners of [3, 4]) {
    const faces = part.faces.filter(face => face.length === corners);
    if (!faces.length) continue;
    commands.push({ op: 0x40, params: [corners === 3 ? 0 : 1] });
    for (const face of faces) for (const vertex of face) {
      const lighting: GpuCommand[] = [];
      if (vertex.color !== undefined) lighting.push({ op: 0x20, params: [vertex.color] });
      if (vertex.normal !== undefined) lighting[vertex.normalLast ? "push" : "unshift"]({ op: 0x21, params: [vertex.normal] });
      commands.push(...lighting);
      if (vertex.texcoord !== undefined) commands.push({ op: 0x22, params: [vertex.texcoord] });
      const [x, y, z] = vertex.position;
      commands.push({ op: 0x23, params: [coord(x0 + x) | (coord(ground + y) << 16), coord(z0 + z)] });
    }
    commands.push({ op: 0x41, params: [] });
  }
  return commands;
}

function faceCounts(parts: readonly { faces: readonly (readonly unknown[])[] }[]) {
  let vertices = 0, polygons = 0, quads = 0;
  for (const part of parts) for (const face of part.faces) {
    vertices += face.length;
    polygons++;
    if (face.length === 4) quads++;
  }
  return { vertices, polygons, quads };
}

function rootStored(file: Uint8Array) {
  const native = readNitroResources(file).models[0];
  return native.renderOps[1]?.kind === "store" && native.renderOps[1].stack === 0 &&
    !native.renderOps.slice(2).some(op => (op.kind === "store" || op.kind === "mix") && op.stack === 0);
}

/** Add trees to a terrain model. The native node data, material records and display lists are kept. */
export function appendMapTrees(modelFile: Uint8Array, trees: readonly TreePlacement[], member: TreeMember = 1) {
  if (!trees.length) return modelFile;
  ensure(rootIsIdentity(modelFile), "This chunk has a transformed root node the tree brush cannot extend.");
  const records = materialRecords(modelFile), originalMaterialCount = records.length;
  const prefix = TREE_SHAPE_PREFIXES[member];
  const bound = new Map<string, NativeMaterialRecord>();
  for (const tree of trees) for (const { record: source } of tree.template.parts) {
    const name = `${prefix}${source.name}`;
    if (bound.has(name)) continue;
    let record = records.find(record => record.name === name);
    if (record) {
      ensure(record.textureName === source.textureName && record.paletteName === source.paletteName, "A custom material conflicts with the tree brush.");
    } else {
      record = { ...source, name };
      records.push(record);
    }
    bound.set(name, record);
  }
  const file = records.length === originalMaterialCount ? modelFile : replaceMaterialRecords(modelFile, records);
  const layout: TerrainModelLayout = terrainModelLayout(file, "tree brush");
  const { scale, shapes, original } = layout;
  const added = faceCounts(trees.flatMap(tree => tree.template.parts));
  ensure(readU16(original, 38) + added.polygons <= 2048 && readU16(original, 36) + added.vertices <= 6144,
    "This chunk has reached the DS geometry limit. Try placing fewer trees.");
  const draws: number[] = [];
  for (const [name, record] of bound) {
    const commands = trees.flatMap(tree => tree.template.parts.filter(part => `${prefix}${part.record.name}` === name)
      .flatMap(part => treeCommands(tree, part, scale)));
    const list = packGrassCommands(commands);
    const existing = shapes.find(shape => shape.name === name);
    if (existing) {
      existing.list = concatBytes([existing.list, list]);
    } else {
      const header = trees.flatMap(tree => tree.template.parts).find(part => `${prefix}${part.record.name}` === name)!.shapeHeader.slice();
      draws.push(4, records.indexOf(record), 5, shapes.length);
      shapes.push({ name, data: new Uint8Array(4), header, list });
    }
  }
  const sbc = extendGrassDraws(layout.sbc, draws, rootStored(file), "tree brush");
  return writeTerrainModel(file, layout, sbc, added, trees.map(treeBox));
}

type PlacedRun = { key: number; commands: GpuCommand[]; vertices: number; polygons: number; quads: number };

function readTreeRuns(list: Uint8Array, member: TreeMember): PlacedRun[] {
  const error = "A placed tree was modified and cannot be removed safely.";
  const commands = readCommands(list, error);
  const runs: PlacedRun[] = [];
  let run: PlacedRun | undefined, prim = -1, verticesInPrim = 0;
  const closePrim = () => {
    if (!run || prim < 0) return;
    const corners = prim === 0 ? 3 : 4;
    ensure(verticesInPrim % corners === 0, error);
    run.polygons += verticesInPrim / corners;
    if (corners === 4) run.quads += verticesInPrim / 4;
  };
  for (const [i, command] of commands.entries()) {
    if (command.op === 0x22 && command.params[0] >>> 16 === TREE_TAG && commands[i + 1]?.op === 0x40) {
      ensure(prim < 0, error);
      const index = command.params[0] & 1023;
      run = { key: treeTileKey(index, member), commands: [command], vertices: 0, polygons: 0, quads: 0 };
      runs.push(run);
      continue;
    }
    ensure(run, error);
    run.commands.push(command);
    if (command.op === 0x40) {
      ensure(prim < 0 && [0, 1].includes(command.params[0]), error);
      prim = command.params[0];
      verticesInPrim = 0;
    } else if (command.op === 0x41) {
      ensure(prim >= 0, error);
      closePrim();
      prim = -1;
    } else if (command.op >= 0x23 && command.op <= 0x28) {
      ensure(prim >= 0, error);
      run.vertices++;
      verticesInPrim++;
    }
  }
  ensure(prim < 0, error);
  return runs;
}

export type PlacedMapTree = { type?: MapTreeType; member: TreeMember; tileIndex: number; size: number };

/** Find trees planted by the tree brush. */
export function readPlacedMapTrees(file: Uint8Array) {
  const layout = terrainModelLayout(file, "tree brush");
  const { native, draws } = shapeMaterials(file);
  const trees = new Map<number, { member: TreeMember; tileIndex: number; size: number; materials: Set<string> }>();
  const shapes = layout.shapes.flatMap((shape, id) => {
    if (!isTreeBrushShape(shape.name)) return [];
    const member = Number(shape.name[1]) as TreeMember;
    const material = draws.filter(draw => draw.shape === id).map(draw => native.materials[draw.material]?.name);
    ensure(material.length === 1 && material[0] === shape.name, "A placed tree has a different draw sequence and cannot be removed safely.");
    const runs = readTreeRuns(shape.list, member);
    for (const run of runs) {
      const tag = run.commands[0].params[0];
      const entry = trees.get(run.key) ?? { member, tileIndex: tag & 1023, size: ((tag >>> 10) & 3) + 2, materials: new Set<string>() };
      entry.materials.add(shape.name.slice(3));
      trees.set(run.key, entry);
    }
    return [{ shape, runs }];
  });
  const placed = new Map<number, PlacedMapTree>();
  for (const [key, { member, tileIndex, size, materials }] of trees) placed.set(key, { type: mapTreeTypeForMaterials(materials), member, tileIndex, size });
  return {
    trees: placed,
    remove(keys: ReadonlySet<number>) {
      const selected = new Set([...keys].filter(key => placed.has(key)));
      if (!selected.size) return file;
      const removed = { vertices: 0, polygons: 0, quads: 0 };
      const lists = new Map<string, Uint8Array>();
      for (const { shape, runs } of shapes) {
        const keep = runs.filter(run => !selected.has(run.key));
        if (keep.length === runs.length) continue;
        for (const run of runs) if (selected.has(run.key)) {
          removed.vertices += run.vertices;
          removed.polygons += run.polygons;
          removed.quads += run.quads;
        }
        // Keep shape indices and bindings stable. A NOP list draws nothing and is reused by the brush.
        lists.set(shape.name, keep.length ? packGrassCommands(keep.flatMap(run => run.commands)) : new Uint8Array(4));
      }
      const next = { ...layout, shapes: layout.shapes.map(shape => ({ ...shape, list: lists.get(shape.name) ?? shape.list })) };
      return writeTerrainModel(file, next, layout.sbc, { vertices: -removed.vertices, polygons: -removed.polygons, quads: -removed.quads });
    },
  };
}
